CREATEURS
---------

Raphael Trancoso <raphael.trancoso@laposte.net>
Cédric Laguerre <ced.laguerre@gmail.com>

Projet de Bases de données avancées.

UTILISATION
-----------

Pour lancer les tests, il suffit d’utiliser psql et de lancer la commande :

\i insertTable.sql

Cette commande va créer les tables, les remplir et exécuter tous les tests.


