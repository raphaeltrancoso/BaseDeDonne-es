\i createTable.sql
\i createTrigger.sql
\echo '\n'
\echo 'MODIFICATION DE LA DATE COURANTE'
SELECT modif_dateCourante('2017-05-10');
\echo '\n'
\echo 'AJOUT DE THEATRES'
SELECT ajout_theatre('LE THEATRE DU CHRYSANTEME', 'FRANCE', 75013, 'PARIS', 300);
SELECT ajout_theatre('THEATRE EXTERIEUR', 'FRANCE', 92100, 'BOULOGNE', 400);

SELECT * FROM theatre;
\echo '\n'
\echo 'AJOUT DE SPECTACLES'
SELECT ajout_spectacle('AHMED SYLLA AVEC UN GRAND A', 'A DOMICILE', 2000.00, 45, 40);
SELECT ajout_spectacle('SILENCE, ON TOURNE!', 'A DOMICILE', 3000.00, 35, 30);
SELECT ajout_spectacle('TOC TOC', 'A DOMICILE', 1000.00, 37, 32);
SELECT ajout_spectacle('ABRACABRUNCH', 'A DOMICILE', 4500.00, 100, 80);
SELECT ajout_spectacle('BLANCHE GARDIN', 'A DOMICILE', 3956.50, 100, 90);
SELECT ajout_spectacle('DESPERATE HOUSEMEN', 'A DOMICILE', 6442.24, 55, 50);
SELECT ajout_spectacle('CHINOIS MARRANT', 'A DOMICILE', 3765.90, 48, 44);
SELECT ajout_spectacle('DUELS A DAVIDEJONATOWN', 'EXTERIEUR', 3500.00, 40, 35);
SELECT ajout_spectacle('MAUVAIS SPECTACLE', 'A DOMICILE', 3500.00, 30, 35);
SELECT * FROM spectacle;

SELECT ajout_organisme('MAIRIE DE PARIS');
SELECT ajout_organisme('MECENAT PRIVE');
SELECT * FROM organisme;

SELECT ajout_subvention(1, 1, 2000.00, 'CREATION PIECE');
SELECT ajout_subvention(2, 1, 3000.00, 'CREATION PIECE');
SELECT * FROM subvention;

SELECT achat_spec('1');
SELECT achat_spec('8');
SELECT * FROM depense;
\echo '\n'
\echo 'AJOUT DE REPRESENTATIONS'
SELECT ajout_representation(250, 1, 1, '2017-05-30', '2017-05-14', '0');
SELECT ajout_representation(250, 1, 2, '2017-05-29', '2017-05-16', '1');
SELECT ajout_representation(250, 1, 3, '2017-05-28', '2017-05-13', '1');
SELECT ajout_representation(10, 1, 4, '2017-05-30', '2017-05-12', '2');
SELECT ajout_representation(10, 1, 5, '2017-05-31', '2017-05-13', '3');
SELECT ajout_representation(100, 1, 6, '2017-05-26', '2017-05-10', '0');
SELECT ajout_representationExterne(2000.00, 2, 1, '2017-05-27');

-- ajouts de représentations qui ne marchent pas
SELECT ajout_representation(400, 1, 1, '2017-05-31', '2017-05-16', '0');
SELECT ajout_representation(300, 1, 2, '2017-05-25', '2017-05-26', '0');
SELECT ajout_representation(300, 1, 2, '2017-05-15', '2017-05-08', '0');
SELECT * FROM representation;
\echo '\n'
\echo 'AJOUT DE BILLETS'
SELECT modif_dateCourante('2017-05-20');
-- ajout de billets normaux avec tarif normal et tarif réduit pour politique 0
SELECT achat_billet(1, 'TARIF NORMAL', 'ACHAT');
SELECT achat_billet(1, 'TARIF REDUIT', 'ACHAT');
SELECT achat_billet(1, 'TARIF NORMAL', 'RESERVATION');

-- ajout de depenses
SELECT ajout_depense('COUT MISE EN SCENE', 100, '2017-05-14', 1) ;
SELECT ajout_depense('COUT MISE EN SCENE', 200, '2017-05-15', 1) ;
SELECT ajout_depense('COUT MISE EN SCENE', 300, '2017-06-02', 1) ;
SELECT ajout_depense('COUT MISE EN SCENE', 50, '2017-06-13', 1) ;
SELECT ajout_depense('COUT MISE EN SCENE', 450, '2017-07-10', 1) ;

-- ajout de billet moins de 5 jours après la mise en vente des billets pour politique 1
SELECT achat_billet(2, 'TARIF NORMAL', 'ACHAT');
-- ajout de billet plus de 5 jours après la mise en vente des billets pour politique 1
SELECT achat_billet(3, 'TARIF NORMAL', 'ACHAT');

-- ajout de billet moins de 15 jours avant la représentation où la salle est remplie à moins de 50% avec politique 2
SELECT achat_billet(4, 'TARIF NORMAL', 'ACHAT');
-- ajout de plus de 30 % mais moins de 50% des billets
SELECT achat_billet(4, 'TARIF NORMAL', 'ACHAT');
SELECT achat_billet(4, 'TARIF NORMAL', 'ACHAT');
-- ajout d'un billet qui aura moins 30%
SELECT achat_billet(4, 'TARIF NORMAL', 'ACHAT');
-- ajout de 50% des billets
SELECT achat_billet(4, 'TARIF NORMAL', 'ACHAT');
-- ajout d'un billet, ici la politique ne s'applique pas car la salle est remplie à plus de 50%
SELECT achat_billet(4, 'TARIF NORMAL', 'ACHAT');

-- ajout d'un billet à moins de 30% des billets vendus
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
-- ajout de billets pour atteindre les 30% de billets vendus
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
-- ajout d'un billet à partir des 30% de billets vendus
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');

-- ajout de billets jusqua ce qu'ils n'y en ait plus de disponible
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');
-- ici il n'y a plus de billets dispo
SELECT achat_billet(5, 'TARIF NORMAL', 'ACHAT');

--
-- SELECT achat_reservation(1);
-- SELECT * FROM reservation;
--

-- ajout d'un billet périmé car la représentation est deja passée
SELECT modif_dateCourante('2017-05-27');
SELECT achat_billet(6, 'TARIF NORMAL', 'ACHAT');
SELECT modif_dateCourante('2017-05-28');
SELECT * FROM billet;
SELECT * FROM reservation;

SELECT recette_spectacle(1);
SELECT recette_spectacle(5);
-- SELECT historique_depenseMoisAnnee();
-- SELECT historique_depenseParSpectacle();
-- SELECT historique_billetParSpectacle();
\i historique.sql
SELECT * FROM tournee_compagnie(1);
